#include <stdio.h>
#include <stdlib.h>
#include "stud.h"

/* Structure used for storing data in file */

typedef struct
{
	int roll;
	char name[NAME_LEN];
	float percentage;
} StudentFile;

void stud_save(void)
{
	FILE *fp;
	Student *temp;
	StudentFile record;
	fp = fopen("student.dat", "wb");
	if (fp == NULL)
	{
		printf("File Opening Error!\n");
		return;
	}
	temp = head;
	while (temp != NULL)
	{
		record.roll = temp->roll;
		snprintf(record.name, sizeof(record.name),"%s", temp->name);
		record.percentage = temp->percentage;
		fwrite(&record, sizeof(record), 1, fp);
		temp = temp->next;
	}
	fclose(fp);
	printf("Records Saved Successfully!\n");
}

void stud_load(void)
{
	FILE *fp;
	StudentFile record;
	Student *newnode, *temp;
	fp = fopen("student.dat", "rb");
	if (fp == NULL)
		return;
	while (fread(&record, sizeof(record), 1, fp) == 1)
	{
		newnode = malloc(sizeof(Student));
		if (newnode == NULL)
		{
			printf("Memory Allocation Failed!\n");
			break;
		}
		newnode->roll = record.roll;
		snprintf(newnode->name, sizeof(newnode->name),"%s", record.name);
		newnode->percentage = record.percentage;
		newnode->next = NULL;
		if (head == NULL){
			head = newnode;
		}
		else
		{
			temp = head;
			while (temp->next != NULL)
				temp = temp->next;
			temp->next = newnode;
		}
	}
	fclose(fp);
}

/* Release all linked-list memory */
void stud_free(void)
{
	Student *temp;
	while (head != NULL)
	{
		temp = head;
		head = head->next;
		free(temp);
	}
}
