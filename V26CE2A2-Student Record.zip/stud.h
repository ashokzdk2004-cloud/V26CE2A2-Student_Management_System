#ifndef STUD_H
#define STUD_H
#define NAME_LEN 50
typedef struct Student
{
	int roll;
	char name[NAME_LEN];
	float percentage;
	struct Student *next;
} Student;

extern Student *head;

void stud_add(void);
void stud_del(void);
void stud_show(void);
void stud_mod(void);
void stud_save(void);
void stud_load(void);
void stud_sort(void);
void stud_free(void);

#endif
