#include <stdio.h>
#include <string.h>
#include "stud.h"

void stud_mod(void)
{
	Student *temp, *selected = NULL;
	char choice, field;
	char name[NAME_LEN];
	int roll, found = 0;
	float percentage;
	if (head == NULL){
		printf("No Records Available!\n");
	return;
	}
	printf("\nR/r: Roll Number\n");
	printf("N/n :Name\n");
	printf("P/p :Percentage\n");
	printf("EnterYour Choice: ");
	scanf(" %c", &choice);
	while (getchar() != '\n') { }
	if (choice == 'r' || choice == 'R')
	{
		printf("Enter Roll Number: ");
		scanf("%d", &roll);
		while (getchar() != '\n') { }
		for (temp = head; temp != NULL; temp = temp->next)
		{
			if (temp->roll == roll)
			{
				selected = temp;
				break;
			}
		}				
	}
	else if (choice == 'n' || choice == 'N')
	{
		printf("Enter Student Name: ");
		fgets(name, sizeof(name), stdin);
		name[strcspn(name, "\n")] = '\0';
		for (temp = head; temp != NULL; temp = temp->next)
		{
			if (strcmp(temp->name, name) == 0)
			{
				printf("Roll: %d Name: %s Percentage: %.2f\n",temp->roll, temp->name, temp->percentage);
				found++;
			}
		}
		if (found == 0)
		{
			printf("Record Not Found!\n");
			return;
		}
		printf("Enter Roll Number to Modify: ");
		scanf("%d", &roll);
		while (getchar() != '\n') { }
		for (temp = head; temp != NULL; temp = temp->next)
		{
			if (temp->roll == roll &&strcmp(temp->name, name) == 0)
			{
				selected = temp;
				break;
			}
		}
	}
	else if (choice == 'p' || choice == 'P')
	{
		printf("Enter Percentage: ");
		scanf("%f", &percentage);
		while (getchar() != '\n') { }
		for (temp = head; temp != NULL; temp = temp->next)
		{
			if (temp->percentage == percentage)
			{
				printf("Roll: %d Name: %s Percentage: %.2f\n",temp->roll, temp->name, temp->percentage);
				found++;
			}
		}
		if (found == 0)
		{
			printf("Record Not Found!\n");
			return;
		}
		printf("Enter Roll Number to Modify: ");
		scanf("%d", &roll);
		while (getchar() != '\n') { }
		for (temp = head; temp != NULL; temp = temp->next)
		{
			if (temp->roll == roll &&temp->percentage == percentage)
			{
				selected = temp;
				break;
			}
		}
	}
	else
	{
		printf("Invalid Choice!\n");
		return;
	}
	if (selected == NULL)
	{
		printf("Record Not Found!\n");
		return;
	}
	printf("\nN/n : Modify Name\n");
	printf("P/p : Modify Percentage\n");
	printf("Enter Your Choice: ");
	scanf(" %c", &field);
	while (getchar() != '\n') { }
	if (field == 'n' || field == 'N')
	{
		printf("Enter New Name: ");
		fgets(name, sizeof(name), stdin);
		name[strcspn(name, "\n")] = '\0';
		if (name[0] == '\0')
		{
			printf("Name cannot be empty.\n");
			return;
		}
		strcpy(selected->name, name);
	}
	else if (field == 'p' || field == 'P')
	{
		printf("Enter New Percentage: ");
		scanf("%f", &percentage);
		while (getchar() != '\n') { }
		if (percentage < 0 || percentage > 100)
		{
			printf("Invalid Percentage!\n");
			return;
		}
		selected->percentage = percentage;
	}
	else
	{
		printf("Invalid Choice!\n");
		return;
	}
	printf("Record Modified Successfully!\n");
}
