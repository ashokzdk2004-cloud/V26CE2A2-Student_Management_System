#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"stud.h"
void stud_del(void)
{
	Student *temp, *prev;
	char choice, name[NAME_LEN];
	int roll, found = 0;
	if (head == NULL){
		printf("No Records Available!\n");
		return;
	}
	printf("\nR/r : Delete using Roll Number\n");
	printf("N/n : Delete using Name\n");
	printf("Enter Your Choice: ");
	scanf(" %c", &choice);
	while (getchar() != '\n') { }
	if (choice == 'r' || choice == 'R')
	{
		printf("Enter Roll Number: ");
		scanf("%d", &roll);
		while (getchar() != '\n') { }
	}
	else if (choice == 'n' || choice == 'N'){
		printf("Enter Student Name: ");
		fgets(name, sizeof(name), stdin);
		name[strcspn(name, "\n")] = '\0';
		printf("\nRoll No\tName\t\tPercentage\n");
		for (temp = head; temp != NULL; temp = temp->next)
		{
			if (strcmp(temp->name, name) == 0)
			{
				printf("%d\t%s\t\t%.2f\n",temp->roll,temp->name,temp->percentage);
				found = 1;
			}
		}
		if (found == 0)
		{
			printf("Record Not Found!\n");
			return;
		}
		printf("Enter Roll Number to Delete: ");
		scanf("%d", &roll);
		while (getchar() != '\n') { }
	}
	else
	{
		printf("Invalid Choice!\n");
		return;
	}
	temp = head;
	prev = NULL;while (temp != NULL && temp->roll != roll)
	{
		prev = temp;
		temp = temp->next;
	}
	if (temp == NULL)
	{
		printf("Record Not Found!\n");
		return;
	}
	if (prev == NULL)
		head = temp->next;
	else
		prev->next = temp->next;
	free(temp);
	printf("Record Deleted Successfully!\n");
}
