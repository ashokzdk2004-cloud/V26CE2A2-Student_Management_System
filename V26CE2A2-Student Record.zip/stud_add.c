#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"stud.h"
void stud_add(void)
{
	Student *newnode, *temp;
	int roll = 1;
	int found;
	char name[NAME_LEN];
	float percentage;
	printf("Enter Student Name: ");
	fgets(name, sizeof(name), stdin);
	name[strcspn(name, "\n")] = '\0';
	if (name[0] == '\0')
	{
		printf("Name cannot be empty.\n");
		return;
	}
	printf("Enter Percentage: ");
	if (scanf("%f", &percentage) != 1)
	{
		printf("Invalid percentage.\n");
		return;
	}
	while (getchar() != '\n') { }
	if (percentage < 0 || percentage > 100)
	{
		printf("Invalid percentage.\n");
		return;
	}
	/* Find smallest available roll number */
	while (1)
	{
		found = 0;
		for (temp = head; temp != NULL; temp = temp->next)
		{
			if (temp->roll == roll)
			{
				found = 1;
				break;
			}
		}		
		if (found == 0)
		break;
		roll++;
	}
	/* Allocate memory */
	newnode = malloc(sizeof(Student));
	if (newnode == NULL)
	{
		printf("Memory allocation failed.\n");
		return;
	}
	newnode->roll = roll;
	strcpy(newnode->name, name);
	newnode->percentage = percentage;
	newnode->next = NULL;
	/* Insert node */
	if (head == NULL)
	{
		head = newnode;
	}
	else
	{
		temp = head;
		while (temp->next != NULL)
			temp = temp->next;temp->next = newnode;
	}
	printf("Record Added Successfully!\n");
	printf("Assigned Roll Number: %d\n", roll);
}
