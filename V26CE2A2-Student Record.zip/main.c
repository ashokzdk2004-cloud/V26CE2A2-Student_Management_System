#include<stdio.h>
#include<ctype.h>
#include"stud.h"
Student *head = NULL;
int main(void)
{
	char choice;
	char exit_choice;stud_load();
	while (1)
	{
		printf("\n***** STUDENT RECORD MENU *****\n");
		printf("A/a : Add New Record\n");
		printf("D/d : Delete a Record\n");
		printf("S/s : Show the List\n");
		printf("M/m : Modify a Record\n");
		printf("V/v : Save\n");
		printf("T/t : Sort the List\n");
		printf("E/e : Exit\n");
		printf("\nEnter Your Choice: ");
		scanf(" %c", &choice);
		while (getchar() != '\n') { }
		switch (tolower((unsigned char)choice))
		{
			case 'a':
				stud_add();
				break;
			case 'd':
				stud_del();
				break;
			case 's':
				stud_show();
				break;
			case 'm':
				stud_mod();
				break;
			case 'v':
				stud_save();
				break;
			case 't':
				stud_sort();
				break;
			case 'e':
				printf("\nS/s : Save and Exit\n");
				printf("E/e : Exit Without Saving\n");
				printf("Enter Your Choice: ");
				scanf(" %c", &exit_choice);
				if (tolower((unsigned char)exit_choice) == 's')
					stud_save();
				else if (tolower((unsigned char)exit_choice) != 'e')
				{
					printf("Invalid choice.\n");
					break;
				}
				stud_free();
				return 0;
			default:
				printf("Invalid Choice!\n");
		}
	}
	return 0;
}
