#include <stdio.h>
#include <string.h>
#include "stud.h"

void stud_sort(void){
	Student *i, *j;
	char choice;
	int roll;
	float percentage;
	char name[NAME_LEN];
	if (head == NULL || head->next == NULL)
	{
		printf("Not Enough Records to Sort!\n");
		return;
	}
	printf("\nN/n : Sort by Name\n");
	printf("P/p : Sort by Percentage\n");
	printf("Enter Your Choice: ");
	scanf(" %c", &choice);
	while (getchar() != '\n') { }
	if (choice != 'n' && choice != 'N' && choice != 'p' && choice != 'P')
	{
		printf("Invalid Choice!\n");
		return;
	}
	for (i = head; i != NULL; i = i->next)
	{
		for (j = i->next; j != NULL; j = j->next)
		{
			int swap = 0;
			if (choice == 'n' || choice == 'N')
			{
				if (strcmp(i->name, j->name) > 0)
				swap = 1;
			}
			else{
				if (i->percentage > j->percentage)
					swap = 1;
			}
			if (swap)
			{
				roll = i->roll;
				i->roll = j->roll;
				j->roll = roll;
				strcpy(name, i->name);
				strcpy(i->name, j->name);
				strcpy(j->name, name);
				percentage = i->percentage;
				i->percentage = j->percentage;
				j->percentage = percentage;
			}
		}		
	}
	printf("Records Sorted Successfully!\n");
}
